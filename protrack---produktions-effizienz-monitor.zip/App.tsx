
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  AlertCircle, 
  Download,
  Zap,
  UserMinus,
  TrendingUp,
  History,
  Clock,
  ClipboardList,
  Target,
  Settings2,
  Pause,
  Play,
  Trash2,
  Wifi,
  WifiOff
} from 'lucide-react';
import { TARGET_MAPPING, ShiftConfig, ProductionEvent, EventType, ShiftType, PRESET_REASONS, Worker } from './types';
import { generatePDF } from './services/pdfService';

const App: React.FC = () => {
  const [config, setConfig] = useState<ShiftConfig | null>(null);
  const [isShiftActive, setIsShiftActive] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [events, setEvents] = useState<ProductionEvent[]>([]);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  const [activeMachineError, setActiveMachineError] = useState<{ startTime: number } | null>(null);
  const [machineErrorSeconds, setMachineErrorSeconds] = useState(0);
  
  const [showReasonModal, setShowReasonModal] = useState<{ type: EventType, workerId?: string } | null>(null);
  const [tempReason, setTempReason] = useState('');

  const [setupGroupLeader, setSetupGroupLeader] = useState('');
  const [setupShiftType, setSetupShiftType] = useState<ShiftType>(ShiftType.EARLY);
  const [setupDate, setSetupDate] = useState(new Date().toISOString().split('T')[0]);

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const machineErrorTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const isResetting = useRef(false);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Load Persistence mit explizitem Reset-Check
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.has('reset')) {
      // Wenn reset-Flag in der URL, sofort alles löschen und URL säubern
      localStorage.clear();
      sessionStorage.clear();
      window.history.replaceState({}, document.title, window.location.pathname);
      return;
    }

    const saved = localStorage.getItem('protrack_v13');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        if (data && data.config) {
          setConfig(data.config);
          setWorkers(data.workers || []);
          setEvents(data.events || []);
          setElapsedSeconds(data.elapsedSeconds || 0);
          setIsShiftActive(data.isShiftActive || false);
          setIsPaused(data.isPaused || false);
          if (data.activeMachineError) setActiveMachineError(data.activeMachineError);
          if (data.machineErrorSeconds) setMachineErrorSeconds(data.machineErrorSeconds);
        }
      } catch (e) { 
        localStorage.removeItem('protrack_v13');
      }
    }
  }, []);

  // Save Persistence (wird blockiert wenn isResetting true ist)
  useEffect(() => {
    if (config && !isResetting.current) {
      const stateToSave = { 
        config, workers, events, elapsedSeconds, isShiftActive, isPaused, activeMachineError, machineErrorSeconds 
      };
      localStorage.setItem('protrack_v13', JSON.stringify(stateToSave));
    }
  }, [config, workers, events, elapsedSeconds, isShiftActive, isPaused, activeMachineError, machineErrorSeconds]);

  // Timer Effekte
  useEffect(() => {
    if (isShiftActive && !isPaused && !isResetting.current) {
      timerRef.current = setInterval(() => setElapsedSeconds(prev => prev + 1), 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [isShiftActive, isPaused]);

  useEffect(() => {
    if (activeMachineError && !isPaused && !isResetting.current) {
      machineErrorTimerRef.current = setInterval(() => setMachineErrorSeconds(prev => prev + 1), 1000);
    } else {
      if (machineErrorTimerRef.current) clearInterval(machineErrorTimerRef.current);
    }
    return () => { if (machineErrorTimerRef.current) clearInterval(machineErrorTimerRef.current); };
  }, [activeMachineError, isPaused]);

  const handleStartShift = (workerCount: number) => {
    if (!setupGroupLeader.trim()) {
      alert('Bitte geben Sie einen Gruppenverantwortlichen an.');
      return;
    }
    isResetting.current = false;
    const newConfig: ShiftConfig = {
      workerCount,
      targetPieces: TARGET_MAPPING[workerCount],
      totalTimeMinutes: 420,
      shiftType: setupShiftType,
      groupLeader: setupGroupLeader,
      date: setupDate
    };
    
    const initialWorkers: Worker[] = Array.from({ length: workerCount }).map((_, i) => ({
      id: `MA-${i + 1}`,
      name: `Mitarbeiter ${i + 1}`,
      pieces: 0,
      isAbsent: false
    }));

    setConfig(newConfig);
    setWorkers(initialWorkers);
    setIsShiftActive(true);
    setIsPaused(false);
    setElapsedSeconds(0);
    setEvents([]);
    setActiveMachineError(null);
    setMachineErrorSeconds(0);
  };

  const stopAndResetShift = async () => {
    if (window.confirm('VORSICHT: Alle Schichtdaten werden gelöscht. Fortfahren?')) {
      isResetting.current = true;
      
      // 1. Alle laufenden Prozesse stoppen
      if (timerRef.current) clearInterval(timerRef.current);
      if (machineErrorTimerRef.current) clearInterval(machineErrorTimerRef.current);

      // 2. Speicher radikal leeren
      localStorage.clear();
      sessionStorage.clear();
      
      // 3. Service Worker abmelden (falls vorhanden), um Caching-Probleme zu vermeiden
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (let registration of registrations) {
          await registration.unregister();
        }
      }

      // 4. Seite hart neu laden mit Cache-Buster
      const freshUrl = window.location.origin + window.location.pathname + '?reset=' + Date.now();
      window.location.href = freshUrl;
    }
  };

  const toggleMachineError = () => {
    if (isPaused) return; 
    if (activeMachineError) {
      setShowReasonModal({ type: EventType.MACHINE_ERROR });
    } else {
      setActiveMachineError({ startTime: Date.now() });
      setMachineErrorSeconds(0);
    }
  };

  const toggleWorkerAbsence = (workerId: string) => {
    if (isPaused) return;
    const worker = workers.find(w => w.id === workerId);
    if (!worker) return;

    if (worker.isAbsent) {
      setShowReasonModal({ type: EventType.WORKER_ABSENCE, workerId });
    } else {
      const absenceId = crypto.randomUUID();
      const newEvent: ProductionEvent = {
        id: absenceId,
        type: EventType.WORKER_ABSENCE,
        workerId,
        startTime: Date.now(),
        durationSeconds: 0,
        reason: 'Abwesend...'
      };
      setEvents(prev => [...prev, newEvent]);
      setWorkers(prev => prev.map(w => w.id === workerId ? { ...w, isAbsent: true, activeAbsenceId: absenceId } : w));
    }
  };

  const finalizeEvent = () => {
    if (!showReasonModal) return;
    if (showReasonModal.type === EventType.MACHINE_ERROR) {
      setEvents(prev => [...prev, {
        id: crypto.randomUUID(),
        type: EventType.MACHINE_ERROR,
        startTime: activeMachineError!.startTime,
        endTime: Date.now(),
        durationSeconds: machineErrorSeconds,
        reason: tempReason || 'Maschinenstörung'
      }]);
      setActiveMachineError(null);
      setMachineErrorSeconds(0);
    } else if (showReasonModal.type === EventType.WORKER_ABSENCE) {
      const worker = workers.find(w => w.id === showReasonModal.workerId);
      if (worker?.activeAbsenceId) {
        const endTime = Date.now();
        setEvents(prev => prev.map(e => {
          if (e.id === worker.activeAbsenceId) {
            const duration = Math.floor((endTime - e.startTime) / 1000);
            return { ...e, endTime, durationSeconds: duration, reason: tempReason || 'Abwesenheit beendet' };
          }
          return e;
        }));
        setWorkers(prev => prev.map(w => w.id === showReasonModal.workerId ? { ...w, isAbsent: false, activeAbsenceId: undefined } : w));
      }
    }
    setTempReason('');
    setShowReasonModal(null);
  };

  const incrementPiece = (workerId: string, amount: number) => {
    if (activeMachineError || isPaused) return; 
    setWorkers(prev => prev.map(w => (w.id === workerId && !w.isAbsent) ? { ...w, pieces: Math.max(0, w.pieces + amount) } : w));
  };

  const totalActualPieces = useMemo(() => workers.reduce((sum, w) => sum + w.pieces, 0), [workers]);
  const shiftSeconds = 420 * 60;
  const targetPerSecondGlobal = config ? config.targetPieces / shiftSeconds : 0;
  const currentTarget = Math.floor(elapsedSeconds * targetPerSecondGlobal);
  const lossPerSecondPerWorker = config ? (config.targetPieces / config.workerCount) / shiftSeconds : 0;
  
  const totalAbsenceLoss = useMemo(() => {
    let accumulatedLoss = 0;
    events.filter(e => e.type === EventType.WORKER_ABSENCE && e.endTime).forEach(e => {
      accumulatedLoss += e.durationSeconds * lossPerSecondPerWorker;
    });
    workers.forEach(w => {
      if (w.isAbsent && w.activeAbsenceId) {
        const event = events.find(e => e.id === w.activeAbsenceId);
        if (event) {
          const currentDurationSec = (Date.now() - event.startTime) / 1000;
          accumulatedLoss += currentDurationSec * lossPerSecondPerWorker;
        }
      }
    });
    return accumulatedLoss;
  }, [events, workers, lossPerSecondPerWorker, elapsedSeconds]);

  const totalDowntimeSeconds = useMemo(() => events.filter(e => e.type === EventType.MACHINE_ERROR).reduce((sum, e) => sum + e.durationSeconds, 0) + machineErrorSeconds, [events, machineErrorSeconds]);
  const totalMachineLoss = useMemo(() => totalDowntimeSeconds * targetPerSecondGlobal, [totalDowntimeSeconds, targetPerSecondGlobal]);
  const efficiency = currentTarget > 0 ? (totalActualPieces / currentTarget) * 100 : 0;
  
  const formatTime = (totalSec: number) => {
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    return `${h > 0 ? h + ':' : ''}${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (!config) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6">
        <div className="max-w-md w-full bg-slate-900 rounded-3xl shadow-2xl p-8 border border-slate-800">
          <div className="flex justify-center mb-6"><Zap className="w-12 h-12 text-blue-500 fill-blue-500" /></div>
          <h1 className="text-2xl font-black text-center text-white mb-8 uppercase tracking-widest">Setup</h1>
          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-500 uppercase ml-1">Verantwortlicher</label>
              <input type="text" value={setupGroupLeader} onChange={(e) => setSetupGroupLeader(e.target.value)} placeholder="Name des Schichtleiters" className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-blue-500 transition-colors" />
            </div>
            <div className="grid grid-cols-2 gap-4">
               <div className="space-y-1">
                 <label className="text-[10px] font-black text-slate-500 uppercase ml-1">Schicht</label>
                 <select value={setupShiftType} onChange={(e) => setSetupShiftType(e.target.value as ShiftType)} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-blue-500">
                    <option value={ShiftType.EARLY}>Frühschicht</option>
                    <option value={ShiftType.LATE}>Spätschicht</option>
                    <option value={ShiftType.NIGHT}>Nachtschicht</option>
                 </select>
               </div>
               <div className="space-y-1">
                 <label className="text-[10px] font-black text-slate-500 uppercase ml-1">Datum</label>
                 <input type="date" value={setupDate} onChange={(e)=>setSetupDate(e.target.value)} className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-white font-bold outline-none focus:border-blue-500" />
               </div>
            </div>
            <div className="pt-6 border-t border-slate-800 mt-4 text-center">
              <p className="text-xs font-black text-slate-400 uppercase mb-4 tracking-widest">Besetzung wählen:</p>
              <div className="grid grid-cols-2 gap-3">
                {Object.keys(TARGET_MAPPING).map((num) => (
                  <button key={num} onClick={() => handleStartShift(parseInt(num))} className="flex flex-col items-center justify-center py-4 bg-slate-800 border border-slate-700 rounded-2xl hover:bg-blue-600 transition-all active:scale-95 group">
                    <span className="text-lg font-black text-white">{num} MA</span>
                    <span className="text-[10px] font-bold text-slate-500 group-hover:text-blue-200">Ziel: {TARGET_MAPPING[parseInt(num)]}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="mt-8 flex items-center justify-center gap-2 text-slate-500 font-bold text-[10px] uppercase">
             {isOnline ? <Wifi className="w-3 h-3 text-emerald-500" /> : <WifiOff className="w-3 h-3 text-red-500" />}
             <span>{isOnline ? 'Online' : 'Offline Mode'}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-slate-950 text-slate-100 flex flex-col font-sans overflow-hidden">
      <header className={`border-b border-white/5 ${activeMachineError ? 'bg-red-950/80' : isPaused ? 'bg-amber-900/40' : 'bg-slate-900'} px-4 py-3 flex items-center justify-between z-50`}>
        <div className="flex items-center gap-3">
          <Zap className="w-5 h-5 text-blue-500 fill-blue-500" />
          <div className="leading-tight">
            <span className="font-black text-xs uppercase block">ProTrack Enterprise</span>
            <span className="text-[8px] text-slate-400 font-bold uppercase tracking-widest truncate max-w-[100px]">{config.groupLeader}</span>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-slate-950/40 px-2 py-1 rounded-xl border border-white/5 shadow-inner">
           <div className="flex flex-col items-center px-3 border-r border-white/10">
             <span className="text-[7px] font-black text-slate-500 uppercase leading-none mb-1">Dauer</span>
             <span className={`text-lg font-mono font-black leading-none ${isPaused ? 'text-amber-500' : 'text-white'}`}>{formatTime(elapsedSeconds)}</span>
           </div>
           
           <div className="flex items-center gap-1.5">
              <button onClick={() => setIsPaused(!isPaused)} className={`p-2 rounded-lg transition-all active:scale-90 ${isPaused ? 'bg-emerald-600' : 'bg-amber-600'}`}>
                {isPaused ? <Play className="w-4 h-4 fill-current" /> : <Pause className="w-4 h-4 fill-current" />}
              </button>
              
              <button onClick={stopAndResetShift} className="p-2 bg-slate-800 hover:bg-red-600 text-white rounded-lg active:scale-90 border border-white/5">
                <Trash2 className="w-4 h-4" />
              </button>
           </div>
        </div>
      </header>

      <main className="flex-grow p-3 grid grid-cols-1 lg:grid-cols-12 gap-3 overflow-hidden relative">
        {isPaused && <div className="absolute inset-0 z-40 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center text-white font-black uppercase text-xl">Pause</div>}

        <div className="lg:col-span-9 flex flex-col gap-3 overflow-y-auto pr-1 pb-10">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
             <div className="bg-slate-900 rounded-xl border border-white/5 p-3 flex flex-col justify-center">
                <p className="text-[7px] font-black text-emerald-400 uppercase mb-1">IST</p>
                <div className="text-2xl font-black text-white font-mono">{totalActualPieces}</div>
             </div>
             <div className="bg-slate-900 rounded-xl border border-white/5 p-3 flex flex-col justify-center">
                <p className="text-[7px] font-black text-blue-400 uppercase mb-1">PLAN</p>
                <div className="text-2xl font-black text-blue-500 font-mono">{currentTarget}</div>
                <p className={`text-[8px] font-black mt-1 uppercase ${efficiency >= 100 ? 'text-emerald-400' : 'text-red-400'}`}>{efficiency.toFixed(1)}%</p>
             </div>
             <div className="bg-slate-900/50 rounded-xl border border-blue-500/30 p-3 flex flex-col justify-center">
                <p className="text-[7px] font-black text-blue-200 uppercase mb-1">SOLL</p>
                <div className="text-2xl font-black text-white font-mono">{config.targetPieces}</div>
             </div>
             <div className="bg-slate-900 rounded-xl border border-white/5 p-3 flex flex-col justify-center">
                <p className="text-[7px] font-black text-orange-400 uppercase mb-1">PERSONAL</p>
                <div className="text-2xl font-black text-orange-500 font-mono">-{totalAbsenceLoss.toFixed(1)}</div>
             </div>
             <div className="bg-slate-900 rounded-xl border border-white/5 p-3 flex flex-col justify-center">
                <p className="text-[7px] font-black text-red-400 uppercase mb-1">STÖRUNG</p>
                <div className="text-2xl font-black text-red-500 font-mono">-{totalMachineLoss.toFixed(1)}</div>
             </div>
             <button onClick={toggleMachineError} disabled={isPaused} className={`rounded-xl font-black text-[10px] uppercase border border-white/5 transition-all active:scale-95 flex flex-col items-center justify-center gap-1 min-h-[70px] ${activeMachineError ? 'bg-red-500 text-white animate-pulse' : 'bg-slate-800 text-red-500'}`}>
                <AlertCircle className="w-5 h-5" />
                {activeMachineError ? formatTime(machineErrorSeconds) : 'STÖRUNG'}
             </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
             {workers.map(worker => (
               <div key={worker.id} className={`p-3 rounded-xl border transition-all ${activeMachineError || isPaused ? 'opacity-40 pointer-events-none' : worker.isAbsent ? 'bg-orange-500/10 border-orange-500/30' : 'bg-slate-900 border-white/5 shadow-xl'}`}>
                 <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                       <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-black ${worker.isAbsent ? 'bg-orange-500 text-white' : 'bg-slate-800 text-slate-400'}`}>{worker.id.split('-')[1]}</div>
                       <div>
                          <span className="text-[10px] font-black text-white uppercase block leading-none">{worker.name}</span>
                          <span className={`text-[7px] font-black uppercase tracking-widest ${worker.isAbsent ? 'text-orange-500' : 'text-emerald-500'}`}>{worker.isAbsent ? 'Pause' : 'Aktiv'}</span>
                       </div>
                    </div>
                    <button onClick={() => toggleWorkerAbsence(worker.id)} className={`p-2 rounded-lg border ${worker.isAbsent ? 'bg-emerald-500 text-white' : 'bg-orange-500/10 text-orange-500 border-orange-500/20'}`}><UserMinus className="w-3.5 h-3.5" /></button>
                 </div>
                 <div className="flex items-center justify-between bg-slate-950/60 rounded-lg p-2 border border-white/5">
                    <div className="flex flex-col"><span className="text-[7px] font-black text-slate-600 uppercase">Stück</span><span className="text-2xl font-mono font-black text-white leading-none">{worker.pieces}</span></div>
                    <div className="flex gap-1.5">
                       <button onClick={() => incrementPiece(worker.id, -1)} className="w-8 h-8 bg-slate-800 rounded-lg flex items-center justify-center active:scale-90 border border-white/5">-</button>
                       <button onClick={() => incrementPiece(worker.id, 1)} className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-xl font-black active:scale-90 shadow-lg">+</button>
                    </div>
                 </div>
               </div>
             ))}
          </div>
        </div>

        <div className="lg:col-span-3 flex flex-col h-full border-l border-white/10 pl-3 gap-3">
           <div className="bg-slate-900 rounded-xl border border-white/5 flex flex-col flex-grow max-h-[50vh] overflow-hidden">
              <div className="p-3 border-b border-white/5 bg-slate-950/20 flex items-center gap-2">
                   <History className="w-3.5 h-3.5 text-slate-500" />
                   <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Logs</span>
              </div>
              <div className="flex-grow overflow-y-auto p-3 space-y-2 bg-slate-950/20">
                 {events.length === 0 ? <p className="text-[8px] text-slate-600 font-bold uppercase text-center py-5">Keine Einträge</p> : 
                    [...events].reverse().slice(0, 20).map(e => (
                       <div key={e.id} className="p-2 bg-slate-900 rounded-lg border border-white/5">
                          <div className="flex justify-between items-start text-[7px] font-black uppercase mb-0.5">
                             <span className={e.type === EventType.MACHINE_ERROR ? 'text-red-500' : 'text-orange-500'}>{e.type}</span>
                             <span className="text-slate-600">{formatTime(e.durationSeconds)}</span>
                          </div>
                          <p className="font-bold text-slate-200 text-[9px] leading-tight">{e.reason}</p>
                       </div>
                    ))
                 }
              </div>
           </div>
           <button onClick={() => generatePDF(config, events, workers, totalActualPieces, currentTarget, efficiency, totalDowntimeSeconds, totalAbsenceLoss, totalMachineLoss)} className="w-full bg-white text-slate-950 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl">
              <Download className="w-3.5 h-3.5" /> PDF Export
           </button>
        </div>
      </main>

      {showReasonModal && (
        <div className="fixed inset-0 z-[100] bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-xs w-full bg-slate-900 rounded-2xl border border-white/10 p-5">
             <h3 className="text-sm font-black text-white uppercase mb-4 tracking-widest">Grund angeben</h3>
             <div className="space-y-4">
                <div className="flex flex-wrap gap-1.5">
                  {PRESET_REASONS[showReasonModal.type].map(reason => (
                    <button key={reason} onClick={() => setTempReason(reason)} className={`px-2 py-1.5 rounded-lg text-[8px] font-black uppercase border transition-all ${tempReason === reason ? 'bg-blue-600 border-blue-400 text-white' : 'bg-slate-950 border-white/5 text-slate-500'}`}>{reason}</button>
                  ))}
                </div>
                <textarea value={tempReason} onChange={(e) => setTempReason(e.target.value)} className="w-full h-20 bg-slate-950 border border-white/5 rounded-xl p-3 text-white text-xs outline-none focus:border-blue-500/50 resize-none" placeholder="Details..." />
                <div className="flex gap-2">
                   <button onClick={() => { setShowReasonModal(null); setTempReason(''); }} className="flex-1 py-3 bg-slate-800 rounded-xl text-[9px] font-black text-slate-400 uppercase">Abbruch</button>
                   <button onClick={finalizeEvent} className="flex-1 py-3 bg-blue-600 rounded-xl text-[9px] font-black text-white uppercase">OK</button>
                </div>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
