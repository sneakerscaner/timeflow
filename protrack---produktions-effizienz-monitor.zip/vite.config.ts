
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Ersetze 'protrack' durch deinen Repository-Namen auf GitHub
export default defineConfig({
  plugins: [react()],
  base: './', // Verwendet relative Pfade, funktioniert überall
  build: {
    outDir: 'dist',
    sourcemap: false
  },
  server: {
    port: 3000
  }
});
