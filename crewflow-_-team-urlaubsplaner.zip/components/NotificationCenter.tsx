
import React from 'react';
import { AppNotification } from '../types';

interface Props {
  notifications: AppNotification[];
}

export const NotificationCenter: React.FC<Props> = ({ notifications }) => {
  const sorted = [...notifications].sort((a, b) => b.timestamp - a.timestamp);

  return (
    <div className="bg-white rounded-3xl shadow-lg border border-slate-100 overflow-hidden">
      <div className="p-6 bg-slate-50 border-b border-slate-100">
        <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
          System-Benachrichtigungen
        </h3>
      </div>
      <div className="max-h-[500px] overflow-y-auto p-4 space-y-3">
        {sorted.map(notif => (
          <div key={notif.id} className="p-4 rounded-2xl bg-white border border-slate-100 hover:border-green-200 transition-all shadow-sm">
            <div className="flex justify-between items-start mb-1">
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                notif.type === 'MANAGER_INFO' ? 'bg-amber-100 text-amber-700' :
                notif.type === 'REMINDER' ? 'bg-blue-100 text-blue-700' :
                'bg-green-100 text-green-700'
              }`}>
                {notif.type.replace('_', ' ')}
              </span>
              <span className="text-[10px] text-slate-400">
                {new Date(notif.timestamp).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
            <h4 className="text-sm font-bold text-slate-800">{notif.title}</h4>
            <p className="text-xs text-slate-500 mt-1 leading-relaxed">{notif.message}</p>
            <div className="mt-2 text-[10px] font-medium text-slate-400 flex items-center gap-1">
              <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m22 7-8.5 5.5L5 7"/><path d="M2 17V7a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2Z"/></svg>
              Gesendet an: {notif.recipient}
            </div>
          </div>
        ))}
        {sorted.length === 0 && (
          <div className="text-center py-12 text-slate-300 italic text-sm">
            Keine aktuellen Benachrichtigungen.
          </div>
        )}
      </div>
    </div>
  );
};
