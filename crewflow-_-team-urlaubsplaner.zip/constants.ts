
import { TeamConfig } from './types';

// Fix: Removed 'maxAway' property to resolve TypeScript error as it is not part of the TeamConfig interface
export const TEAM_CONFIG: TeamConfig = {
  totalStaff: 30,
  minRequiredStaff: 13,
};

export const INITIAL_DATA_KEY = 'team_holiday_data_v1';
