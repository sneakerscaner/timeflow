
import React from 'react';
import { TeamConfig } from '../types';

interface Props {
  totalRequests: number;
  approvedCount: number;
  config: TeamConfig;
}

export const StatsCards: React.FC<Props> = ({ totalRequests, approvedCount, config }) => {
  return (
    <div className="relative -mt-20 mb-20 z-20 container mx-auto px-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
        <div className="absolute top-1/2 left-[10%] right-[10%] h-[2px] bg-gradient-to-r from-transparent via-teal-100 to-transparent -z-10 hidden md:block"></div>

        <div className="group bg-white p-10 rounded-[2.5rem] shadow-2xl shadow-slate-200/40 border border-slate-50 text-center flex flex-col items-center transition-all hover:-translate-y-2">
          <span className="text-6xl font-black text-teal-600 mb-2 tracking-tighter">{config.totalStaff}</span>
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.2em]">Team-Mitglieder</span>
        </div>

        <div className="group bg-white p-10 rounded-[2.5rem] shadow-2xl shadow-slate-200/40 border border-teal-100 text-center flex flex-col items-center md:scale-105 transition-all hover:-translate-y-2">
          <span className="text-6xl font-black text-teal-600 mb-2 tracking-tighter">{config.minRequiredStaff}</span>
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.2em]">Mindestpräsenz</span>
        </div>

        <div className="group bg-white p-10 rounded-[2.5rem] shadow-2xl shadow-slate-200/40 border border-slate-50 text-center flex flex-col items-center transition-all hover:-translate-y-2">
          <span className="text-6xl font-black text-teal-600 mb-2 tracking-tighter">{approvedCount}</span>
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.2em]">Gen. Urlaube</span>
        </div>
      </div>
    </div>
  );
};
