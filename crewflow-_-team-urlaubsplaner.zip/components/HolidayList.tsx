
import React from 'react';
import { HolidayRequest, RequestStatus } from '../types';
import { formatGermanDate } from '../utils/dateUtils';

interface Props {
  requests: HolidayRequest[];
}

export const HolidayList: React.FC<Props> = ({ requests }) => {
  const sorted = [...requests].sort((a, b) => b.createdAt - a.createdAt);

  return (
    <div className="bg-white rounded-[2.5rem] shadow-2xl shadow-slate-200/40 border border-slate-50 overflow-hidden">
      <div className="p-10 border-b border-slate-50 flex justify-between items-center bg-white">
        <h2 className="text-2xl font-black text-slate-900 tracking-tight">Historie</h2>
        <span className="text-xs font-bold text-slate-400 uppercase tracking-widest bg-slate-50 px-4 py-1.5 rounded-full">
          {requests.length} Anträge
        </span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50 text-slate-400 text-[10px] font-bold uppercase tracking-[0.2em]">
              <th className="px-10 py-5">Team-Mitglied</th>
              <th className="px-10 py-5">Zeitraum</th>
              <th className="px-10 py-5">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {sorted.map((req) => (
              <tr key={req.id} className="hover:bg-slate-50/50 transition-colors group">
                <td className="px-10 py-6">
                  <div className="flex items-center gap-2">
                    <div className="font-bold text-slate-800 group-hover:text-teal-600 transition-colors">{req.employeeName}</div>
                    {req.hasSchoolChildren && (
                      <div className="w-6 h-6 bg-teal-50 text-teal-600 rounded-full flex items-center justify-center" title="Hat schulpflichtige Kinder">
                        <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m2 22 2-4h1a2 2 0 0 1 2 2v2"/><path d="M9 3v11"/><path d="M10 22c0-3 1-5 2-6"/><path d="M13 11a2 2 0 0 1 2 2v1"/><path d="M15 22v-4a2 2 0 0 1 2-2h1a2 2 0 0 1 2 2v4"/><path d="M18 14h1a2 2 0 0 1 2 2v2"/><path d="M22 22h-1c-2 0-3-1-3-3"/><path d="M5 14v7"/><path d="M7 11a2 2 0 0 1 2 2v1"/><path d="M8 22c0-3-1-5-2-6"/></svg>
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-10 py-6 text-sm text-slate-500 font-medium">
                  {formatGermanDate(req.startDate)} – {formatGermanDate(req.endDate)}
                </td>
                <td className="px-10 py-6">
                  <span className={`inline-flex items-center px-5 py-2 rounded-xl text-xs font-bold shadow-sm ${
                    req.status === RequestStatus.APPROVED || req.status === RequestStatus.PRIORITY 
                    ? 'bg-teal-100 text-teal-700 shadow-teal-50' : 
                    req.status === RequestStatus.REJECTED ? 'bg-rose-100 text-rose-700 shadow-rose-50' : 
                    'bg-slate-100 text-slate-600 shadow-slate-50'
                  }`}>
                    {req.status === RequestStatus.APPROVED ? 'Genehmigt' : 
                     req.status === RequestStatus.PRIORITY ? 'Priorität-Gen.' :
                     req.status === RequestStatus.REJECTED ? 'Abgelehnt' : 'Pending'}
                  </span>
                </td>
              </tr>
            ))}
            {sorted.length === 0 && (
              <tr>
                <td colSpan={3} className="px-10 py-24 text-center text-slate-300 italic text-sm">
                  Aktuell sind keine Anträge im System hinterlegt.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
