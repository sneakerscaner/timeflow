
import React, { useState } from 'react';
import { RequestStatus } from '../types';

interface Props {
  onSubmit: (name: string, start: string, end: string, hasSchoolChildren: boolean) => Promise<{ status: RequestStatus, reason: string }>;
  onAdminLogin: () => void;
}

export const EmployeePortal: React.FC<Props> = ({ onSubmit, onAdminLogin }) => {
  const [name, setName] = useState('');
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [hasChildren, setHasChildren] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<{ status: RequestStatus, reason: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !start || !end) return;
    
    setIsSubmitting(true);
    const res = await onSubmit(name, start, end, hasChildren);
    setResult(res);
    setIsSubmitting(false);
  };

  if (result) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white rounded-[2.5rem] shadow-2xl p-10 text-center border border-slate-100">
          <div className={`w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-6 ${
            result.status !== RequestStatus.REJECTED ? 'bg-teal-100 text-teal-600' : 'bg-rose-100 text-rose-500'
          }`}>
            {result.status !== RequestStatus.REJECTED ? (
              <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
            )}
          </div>
          <h2 className="text-2xl font-black text-slate-800 mb-4 tracking-tight">
            {result.status !== RequestStatus.REJECTED ? 'Antrag genehmigt!' : 'Nicht möglich'}
          </h2>
          <p className="text-slate-500 text-sm leading-relaxed mb-8">
            {result.status !== RequestStatus.REJECTED 
              ? `Deine Urlaubszeit wurde erfolgreich in CrewFlow gespeichert.${result.status === RequestStatus.PRIORITY ? ' (Priorität berücksichtigt)' : ''} Wir wünschen gute Erholung!`
              : 'An diesen Tagen ist die Mindestbesetzung bereits erreicht. Bitte wähle einen anderen Zeitraum.'}
          </p>
          <button 
            onClick={() => setResult(null)}
            className="w-full py-4 bg-teal-600 text-white font-bold rounded-2xl hover:bg-teal-700 transition-all shadow-lg shadow-teal-100"
          >
            Neuer Antrag
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
      <div className="flex items-center gap-3 mb-10">
        <div className="w-10 h-10 bg-teal-600 rounded-xl flex items-center justify-center shadow-lg shadow-teal-200">
          <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
        </div>
        <span className="text-2xl font-black tracking-tight text-slate-900">CrewFlow</span>
      </div>

      <div className="max-w-md w-full bg-white rounded-[2.5rem] shadow-2xl shadow-slate-200/50 p-10 border border-slate-50">
        <h2 className="text-2xl font-black text-slate-800 mb-2 tracking-tight">Urlaubszettel</h2>
        <p className="text-slate-400 text-sm mb-8">Digitaler Antrag für die Crew.</p>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Dein Name</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="z.B. Julia Sommer"
              className="w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-teal-500 outline-none transition-all placeholder:text-slate-300 font-medium"
            />
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Beginn</label>
              <input
                type="date"
                required
                value={start}
                onChange={(e) => setStart(e.target.value)}
                className="w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-teal-500 outline-none transition-all font-medium"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2">Ende</label>
              <input
                type="date"
                required
                value={end}
                onChange={(e) => setEnd(e.target.value)}
                className="w-full px-5 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-teal-500 outline-none transition-all font-medium"
              />
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 bg-teal-50 rounded-2xl border border-teal-100">
            <input 
              type="checkbox" 
              id="children" 
              checked={hasChildren}
              onChange={(e) => setHasChildren(e.target.checked)}
              className="w-5 h-5 accent-teal-600 rounded"
            />
            <label htmlFor="children" className="text-xs font-bold text-teal-800 leading-tight">
              Ich habe schulpflichtige Kinder <br/>
              <span className="text-[10px] font-medium opacity-60">(Wird bei der Priorisierung berücksichtigt)</span>
            </label>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-teal-600 hover:bg-teal-700 text-white font-bold py-5 rounded-2xl shadow-xl shadow-teal-200 transition-all disabled:opacity-50 mt-4 flex items-center justify-center gap-3"
          >
            {isSubmitting ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                Validierung...
              </>
            ) : 'Antrag jetzt einreichen'}
          </button>
        </form>
      </div>

      <div className="mt-12 opacity-20 hover:opacity-100 transition-opacity">
        <button 
          onClick={onAdminLogin}
          className="text-[10px] text-slate-400 font-bold uppercase tracking-widest hover:text-teal-600 transition-colors"
        >
          System-Administrator Login
        </button>
      </div>
    </div>
  );
};
