
import React from 'react';
import { TeamConfig } from '../types';

interface Props {
  config: TeamConfig;
  setConfig: (config: TeamConfig) => void;
}

export const SettingsCard: React.FC<Props> = ({ config, setConfig }) => {
  return (
    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-xl flex flex-col sm:flex-row gap-6 items-center">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-500">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.1a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
        </div>
        <div>
          <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider">Konfiguration</h3>
          <p className="text-[10px] text-slate-400 font-bold uppercase">Team-Parameter anpassen</p>
        </div>
      </div>
      
      <div className="flex gap-6">
        <div className="flex flex-col">
          <label className="text-[9px] font-bold text-slate-400 uppercase mb-1">Mitarbeiter gesamt</label>
          <input 
            type="number" 
            value={config.totalStaff}
            onChange={(e) => setConfig({ ...config, totalStaff: parseInt(e.target.value) || 0 })}
            className="w-20 px-3 py-2 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-teal-500 font-bold text-slate-800 text-sm"
          />
        </div>
        <div className="flex flex-col">
          <label className="text-[9px] font-bold text-slate-400 uppercase mb-1">Mindestpräsenz</label>
          <input 
            type="number" 
            value={config.minRequiredStaff}
            onChange={(e) => setConfig({ ...config, minRequiredStaff: parseInt(e.target.value) || 0 })}
            className="w-20 px-3 py-2 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-teal-500 font-bold text-slate-800 text-sm"
          />
        </div>
      </div>
    </div>
  );
};
