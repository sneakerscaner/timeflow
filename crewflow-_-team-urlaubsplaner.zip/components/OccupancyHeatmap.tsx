
import React from 'react';
import { getDatesInRange, isWeekend } from '../utils/dateUtils';
import { HolidayRequest, RequestStatus, TeamConfig } from '../types';

interface Props {
  requests: HolidayRequest[];
  config: TeamConfig & { maxAway: number };
}

export const OccupancyHeatmap: React.FC<Props> = ({ requests, config }) => {
  const today = new Date();
  const next30Days = getDatesInRange(
    today.toISOString().split('T')[0],
    new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );

  const approved = requests.filter(r => r.status === RequestStatus.APPROVED || r.status === RequestStatus.PRIORITY);

  return (
    <div className="bg-white p-10 rounded-[2.5rem] shadow-2xl shadow-slate-200/40 border border-slate-50">
      <h2 className="text-2xl font-black mb-8 text-slate-900 tracking-tight">Team-Auslastung</h2>
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 lg:grid-cols-10 gap-3">
        {next30Days.map(date => {
          const awayCount = approved.filter(req => date >= req.startDate && date <= req.endDate).length;
          const occupancy = config.totalStaff - awayCount;
          const isFull = awayCount >= config.maxAway;
          const isWarn = awayCount >= config.maxAway - 3;
          const weekend = isWeekend(date);

          return (
            <div 
              key={date}
              className={`p-4 rounded-2xl border transition-all text-center flex flex-col items-center justify-center ${
                weekend ? 'bg-slate-50 border-slate-100 opacity-40' :
                isFull ? 'bg-rose-50 border-rose-100 shadow-sm' :
                isWarn ? 'bg-amber-50 border-amber-100 shadow-sm' :
                'bg-teal-50 border-teal-100 shadow-sm'
              }`}
            >
              <span className="text-[10px] font-bold text-slate-400 uppercase mb-1">
                {new Date(date).toLocaleDateString('de-DE', { weekday: 'short' })}
              </span>
              <span className="text-sm font-extrabold text-slate-800">
                {new Date(date).getDate()}.{new Date(date).getMonth() + 1}.
              </span>
              <div className={`mt-2 text-sm font-black ${
                isFull ? 'text-rose-600' : isWarn ? 'text-amber-600' : 'text-teal-600'
              }`}>
                {occupancy}
              </div>
            </div>
          );
        })}
      </div>
      <div className="mt-10 pt-6 border-t border-slate-50 flex flex-wrap gap-8 text-[10px] font-bold uppercase tracking-widest text-slate-400">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-teal-500"></div>
          <span>Gute Besetzung (≥{config.minRequiredStaff})</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-amber-500"></div>
          <span>Kapazität knapp</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full bg-rose-500"></div>
          <span>Limit erreicht (Max. {config.maxAway} weg)</span>
        </div>
      </div>
    </div>
  );
};
