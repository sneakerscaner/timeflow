
import React from 'react';

interface Props {
  onStartClick?: () => void;
}

export const Hero: React.FC<Props> = ({ onStartClick }) => {
  return (
    <section className="relative pt-20">
      <div className="bg-hero h-[600px] flex items-center relative overflow-hidden">
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <h1 className="text-5xl md:text-7xl font-black leading-tight mb-6 text-white tracking-tight">
              Dein Team im Flow:<br />
              <span className="text-teal-400">Digitaler Urlaubsplaner.</span>
            </h1>
            <p className="text-xl md:text-2xl text-slate-100 opacity-95 font-light max-w-2xl leading-relaxed mb-10">
              Mitarbeiter reichen Anträge mobil ein, CrewFlow prüft automatisch die 
              Mindestbesetzung. Transparent, fair und komplett papierlos.
            </p>
            <div className="flex flex-col sm:flex-row gap-5">
              <button 
                onClick={onStartClick}
                className="px-10 py-5 bg-teal-500 hover:bg-teal-400 text-white font-bold rounded-2xl transition-all shadow-xl shadow-teal-900/30 text-lg"
              >
                Mitarbeiter-Portal öffnen
              </button>
              <a href="#calendar" className="px-10 py-5 bg-white/10 hover:bg-white/20 text-white font-bold rounded-2xl transition-all backdrop-blur-md border border-white/30 text-lg text-center">
                Belegungsplan
              </a>
            </div>
          </div>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 h-24 bg-white" style={{ clipPath: 'polygon(0 100%, 100% 100%, 100% 0, 0 100%)' }}></div>
      </div>
    </section>
  );
};
