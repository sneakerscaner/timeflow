
import { GoogleGenAI, Type } from "@google/genai";
import { HolidayRequest, TeamConfig, RequestStatus } from "../types";

// Fix: Initializing GoogleGenAI with API_KEY directly from process.env as per SDK guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getHRInsight = async (
  requests: HolidayRequest[], 
  config: TeamConfig & { maxAway: number }
) => {
  // Fix: Use RequestStatus enum for type safety and consistency
  const approved = requests.filter(r => r.status === RequestStatus.APPROVED || r.status === RequestStatus.PRIORITY);
  const prompt = `
    Du bist ein HR-Assistent für ein Team von ${config.totalStaff} Mitarbeitern.
    Mindestens ${config.minRequiredStaff} müssen anwesend sein, d.h. maximal ${config.maxAway} dürfen gleichzeitig im Urlaub sein.
    WICHTIG: Mitarbeiter mit schulpflichtigen Kindern werden bevorzugt behandelt.
    
    Aktuelle genehmigte Urlaube:
    ${JSON.stringify(approved)}

    Analysiere die Situation kurz und gib Tipps zur Personalplanung. 
    Berücksichtige dabei besonders die Fairness gegenüber Eltern.
    Halte dich kurz und professionell. Antworte auf Deutsch.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    // Accessing .text property directly as per latest SDK guidelines
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Die KI-Analyse ist derzeit nicht verfügbar.";
  }
};

export const generateRejectionMessage = async (
  name: string,
  start: string,
  end: string,
  violationDates: string[]
) => {
  const prompt = `
    Ein Urlaubsantrag von ${name} (${start} bis ${end}) wurde abgelehnt, weil die Mindestbesetzung unterschritten würde an: ${violationDates.join(', ')}.
    Schreibe eine sehr höfliche, professionelle Ablehnungs-E-Mail (nur den Textkörper). 
    Erkläre kurz, dass wir gesetzliche oder betriebliche Mindestbesetzungen wahren müssen.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    // Accessing .text property directly as per latest SDK guidelines
    return response.text;
  } catch (error) {
    return `Leider kann Ihr Antrag für den Zeitraum ${start} bis ${end} nicht genehmigt werden, da an einigen Tagen bereits das Maximum an Abwesenheiten erreicht ist.`;
  }
};
