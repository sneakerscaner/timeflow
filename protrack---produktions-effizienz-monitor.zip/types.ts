
export enum EventType {
  MACHINE_ERROR = 'Maschinenstörung',
  WORKER_ABSENCE = 'Personalabgang'
}

export enum ShiftType {
  EARLY = 'Frühschicht',
  LATE = 'Spätschicht',
  NIGHT = 'Nachtschicht'
}

export interface ProductionEvent {
  id: string;
  type: EventType;
  workerId?: string;
  startTime: number; 
  endTime?: number;  
  durationSeconds: number;
  reason: string;
}

export interface Worker {
  id: string;
  name: string;
  pieces: number;
  isAbsent: boolean;
  activeAbsenceId?: string;
}

export interface ShiftConfig {
  workerCount: number;
  targetPieces: number;
  totalTimeMinutes: number;
  shiftType: ShiftType;
  groupLeader: string;
  date: string;
}

export const TARGET_MAPPING: Record<number, number> = {
  5: 75,
  6: 89,
  7: 113,
  8: 129,
  9: 146,
  10: 158,
  11: 164
};

export const PRESET_REASONS = {
  [EventType.MACHINE_ERROR]: [
    'Werkzeugwechsel',
    'Materialmangel',
    'Maschinendefekt',
    'Sensorfehler',
    'Reinigung'
  ],
  [EventType.WORKER_ABSENCE]: [
    'Pause',
    'Einsatz andere Linie',
    'Krankheit/Sanitäter',
    'Besprechung'
  ]
};
