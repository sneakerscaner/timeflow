
export enum RequestStatus {
  PENDING = 'PENDING',
  APPROVED = 'APPROVED',
  REJECTED = 'REJECTED',
  PRIORITY = 'PRIORITY'
}

export interface HolidayRequest {
  id: string;
  employeeName: string;
  startDate: string;
  endDate: string;
  status: RequestStatus;
  hasSchoolChildren: boolean;
  rejectionReason?: string;
  createdAt: number;
}

export interface TeamConfig {
  totalStaff: number;
  minRequiredStaff: number;
}

export interface AppNotification {
  id: string;
  type: 'MANAGER_INFO' | 'EMPLOYEE_STATUS' | 'REMINDER';
  title: string;
  message: string;
  recipient: string;
  timestamp: number;
}
