
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ShiftConfig, ProductionEvent, EventType, Worker } from '../types';

export const generatePDF = (
  config: ShiftConfig,
  events: ProductionEvent[],
  workers: Worker[],
  actualPieces: number,
  currentTarget: number,
  efficiency: number,
  totalDowntimeSeconds: number,
  totalAbsenceLoss: number,
  totalMachineLoss: number
) => {
  const doc = new jsPDF();
  const creationTime = new Date().toLocaleString('de-DE');
  const dateStr = new Date(config.date).toLocaleDateString('de-DE');

  const formatDuration = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}m ${s}s`;
  };

  // Modern Corporate Header
  doc.setFillColor(15, 23, 42); 
  doc.rect(0, 0, 210, 50, 'F');
  
  doc.setFontSize(28);
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.text('SCHICHT-REPORT', 14, 25);
  
  doc.setFontSize(10);
  doc.setTextColor(148, 163, 184); 
  doc.setFont('helvetica', 'normal');
  doc.text(`SYSTEM: PROTRACK ENTERPRISE`, 14, 34);
  doc.text(`DATUM: ${dateStr} | SCHICHT: ${config.shiftType}`, 14, 40);
  doc.text(`ERSTELLT AM: ${creationTime}`, 14, 46);

  // General KPIs Section
  doc.setFontSize(14);
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.text('LINIEN-KENNZAHLEN', 14, 65);

  const kpiData = [
    ['Gruppenleitung', config.groupLeader, 'Soll-Vorgabe (Schicht)', `${config.targetPieces} Stk.`],
    ['Besetzung', `${config.workerCount} MA`, 'Ist-Ausbringung', `${actualPieces} Stk.`],
    ['Stück-Verlust (Abwesenheit)', `-${totalAbsenceLoss.toFixed(2)} Stk.`, 'Stück-Verlust (Störung)', `-${totalMachineLoss.toFixed(2)} Stk.`],
    ['Effizienz (Aktuell)', `${efficiency.toFixed(2)} %`, 'Gesamt-Downtime', formatDuration(totalDowntimeSeconds)]
  ];

  autoTable(doc, {
    startY: 70,
    body: kpiData,
    theme: 'plain',
    styles: { fontSize: 9, cellPadding: 3 },
    columnStyles: { 
      0: { fontStyle: 'bold', textColor: [100, 116, 139] },
      2: { fontStyle: 'bold', textColor: [100, 116, 139] }
    }
  });

  // Individual Worker Performance Table
  const currentYAfterKpi = (doc as any).lastAutoTable.finalY + 15;
  doc.setFontSize(14);
  doc.text('PERFORMANCE PRO MITARBEITER', 14, currentYAfterKpi);

  const shiftSeconds = 420 * 60;
  const lossPerSecondPerWorker = (config.targetPieces / config.workerCount) / shiftSeconds;

  const workerRows = workers.map(w => {
    const workerAbsences = events.filter(e => e.type === EventType.WORKER_ABSENCE && e.workerId === w.id);
    const totalAbsenceTime = workerAbsences.reduce((sum, e) => sum + e.durationSeconds, 0);
    const pieceLoss = totalAbsenceTime * lossPerSecondPerWorker;

    return [
      w.id,
      w.name,
      `${w.pieces} Stk.`,
      formatDuration(totalAbsenceTime),
      `-${pieceLoss.toFixed(2)} Stk.`
    ];
  });

  autoTable(doc, {
    startY: currentYAfterKpi + 5,
    head: [['ID', 'Name', 'Stückzahl', 'Summe Abwesenheit', 'Verlust (Stk)']],
    body: workerRows,
    theme: 'striped',
    headStyles: { fillColor: [15, 23, 42] },
    styles: { fontSize: 9 }
  });

  // Events & Details
  const currentYAfterWorkers = (doc as any).lastAutoTable.finalY + 15;
  doc.setFontSize(14);
  doc.text('PROTOKOLLIERTE ABWEICHUNGEN', 14, currentYAfterWorkers);

  const allEvents = events.map(e => [
    e.type,
    new Date(e.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    formatDuration(e.durationSeconds),
    e.reason
  ]);

  if (allEvents.length === 0) {
    doc.setFontSize(9);
    doc.text('Keine Abweichungen dokumentiert.', 14, currentYAfterWorkers + 10);
  } else {
    autoTable(doc, {
      startY: currentYAfterWorkers + 5,
      head: [['Typ', 'Uhrzeit', 'Dauer', 'Grund']],
      body: allEvents,
      theme: 'grid',
      headStyles: { fillColor: [100, 116, 139] },
      styles: { fontSize: 9 }
    });
  }

  // Final Footer
  const pageCount = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    const pageHeight = doc.internal.pageSize.height;
    doc.setFontSize(8);
    doc.setTextColor(150);
    doc.text('ProTrack Enterprise Production Report', 14, pageHeight - 15);
    doc.text(`Seite ${i} von ${pageCount}`, 180, pageHeight - 15);
  }

  doc.save(`ShiftReport_${dateStr.replace(/\./g, '_')}_${config.shiftType}.pdf`);
};
