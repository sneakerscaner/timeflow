
import React from 'react';

interface Props {
  onPortalClick?: () => void;
}

export const Header: React.FC<Props> = ({ onPortalClick }) => {
  return (
    <header className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md shadow-sm z-50 border-b border-slate-100">
      <div className="container mx-auto px-6 h-20 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-teal-600 rounded-xl flex items-center justify-center shadow-lg shadow-teal-200">
            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
          </div>
          <span className="text-2xl font-extrabold tracking-tight text-slate-900">CrewFlow</span>
        </div>
        
        <nav className="hidden md:flex items-center gap-10">
          <a href="#" className="text-sm font-bold text-slate-500 hover:text-teal-600 transition-colors">DASHBOARD</a>
          <a href="#calendar" className="text-sm font-bold text-slate-500 hover:text-teal-600 transition-colors">KALENDER</a>
          <button 
            onClick={onPortalClick}
            className="px-6 py-2.5 bg-teal-600 text-white rounded-xl text-sm font-bold hover:bg-teal-700 transition-all shadow-md shadow-teal-100"
          >
            Mitarbeiter-Portal
          </button>
        </nav>
      </div>
    </header>
  );
};
