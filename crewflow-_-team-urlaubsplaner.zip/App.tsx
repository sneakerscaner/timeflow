
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { HolidayRequest, RequestStatus, AppNotification, TeamConfig } from './types';
import { INITIAL_DATA_KEY } from './constants';
import { getDatesInRange, formatGermanDate } from './utils/dateUtils';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { StatsCards } from './components/StatsCards';
import { HolidayList } from './components/HolidayList';
import { OccupancyHeatmap } from './components/OccupancyHeatmap';
import { NotificationCenter } from './components/NotificationCenter';
import { EmployeePortal } from './components/EmployeePortal';
import { SettingsCard } from './components/SettingsCard';
import { getHRInsight, generateRejectionMessage } from './services/geminiService';

type ViewMode = 'manager' | 'employee';

const App: React.FC = () => {
  const [viewMode, setViewMode] = useState<ViewMode>('manager');
  const [requests, setRequests] = useState<HolidayRequest[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [config, setConfig] = useState<TeamConfig>({
    totalStaff: 30,
    minRequiredStaff: 13
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [insight, setInsight] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const maxAway = useMemo(() => config.totalStaff - config.minRequiredStaff, [config]);

  // Load from LocalStorage
  useEffect(() => {
    const savedReqs = localStorage.getItem(INITIAL_DATA_KEY);
    const savedNotifs = localStorage.getItem('crewflow_notifs');
    const savedConfig = localStorage.getItem('crewflow_config');
    
    if (savedReqs) setRequests(JSON.parse(savedReqs));
    if (savedNotifs) setNotifications(JSON.parse(savedNotifs));
    if (savedConfig) setConfig(JSON.parse(savedConfig));
    
    // Auto-detect portal mode from URL
    if (window.location.hash === '#portal') {
      setViewMode('employee');
    }

    const handleHashChange = () => {
      if (window.location.hash === '#portal') setViewMode('employee');
      else setViewMode('manager');
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  useEffect(() => {
    localStorage.setItem(INITIAL_DATA_KEY, JSON.stringify(requests));
    localStorage.setItem('crewflow_notifs', JSON.stringify(notifications));
    localStorage.setItem('crewflow_config', JSON.stringify(config));
  }, [requests, notifications, config]);

  const addNotification = (notif: Omit<AppNotification, 'id' | 'timestamp'>) => {
    const newNotif: AppNotification = {
      ...notif,
      id: crypto.randomUUID(),
      timestamp: Date.now(),
    };
    setNotifications(prev => [newNotif, ...prev].slice(0, 50));
  };

  const fetchInsight = useCallback(async () => {
    if (viewMode !== 'manager') return;
    setIsAnalyzing(true);
    const result = await getHRInsight(requests, { ...config, maxAway });
    setInsight(result || "Aktuell keine Auffälligkeiten in der Planung.");
    setIsAnalyzing(false);
  }, [requests, config, maxAway, viewMode]);

  useEffect(() => {
    if (requests.length > 0 && viewMode === 'manager') {
       fetchInsight();
    }
  }, [requests.length, config, viewMode, fetchInsight]);

  const handleNewRequest = async (name: string, start: string, end: string, hasSchoolChildren: boolean) => {
    setIsSubmitting(true);
    
    addNotification({
      type: 'MANAGER_INFO',
      title: hasSchoolChildren ? 'Prioritäts-Antrag (Eltern)' : 'Neuer mobiler Crew-Antrag',
      message: `${name} ${hasSchoolChildren ? '(mit Kindern) ' : ''}hat einen Antrag gestellt (${formatGermanDate(start)} - ${formatGermanDate(end)}).`,
      recipient: 'admin@crewflow.io'
    });

    const requestedDates = getDatesInRange(start, end);
    const approvedRequests = requests.filter(r => r.status === RequestStatus.APPROVED || r.status === RequestStatus.PRIORITY);
    
    const violations: string[] = [];
    for (const date of requestedDates) {
      const awayOnThisDay = approvedRequests.filter(req => date >= req.startDate && date <= req.endDate).length;
      const dynamicLimit = hasSchoolChildren ? maxAway + 1 : maxAway;
      if (awayOnThisDay >= dynamicLimit) {
        violations.push(date);
      }
    }

    let status = hasSchoolChildren ? RequestStatus.PRIORITY : RequestStatus.APPROVED;
    let reason = "";

    if (violations.length > 0) {
      status = RequestStatus.REJECTED;
      reason = await generateRejectionMessage(name, start, end, violations);
      addNotification({
        type: 'EMPLOYEE_STATUS',
        title: 'Antrag automatisch abgelehnt',
        message: `Mindestbesetzung an ${violations.length} Tag(en) kritisch.`,
        recipient: `${name.toLowerCase().replace(' ', '.')}@crew.de`
      });
    } else {
      addNotification({
        type: 'EMPLOYEE_STATUS',
        title: hasSchoolChildren ? 'Prioritäts-Urlaub bestätigt' : 'Urlaub automatisch genehmigt',
        message: `CrewFlow hat den Zeitraum ${formatGermanDate(start)} - ${formatGermanDate(end)} bestätigt.`,
        recipient: `${name.toLowerCase().replace(' ', '.')}@crew.de`
      });
    }

    const newReq: HolidayRequest = {
      id: crypto.randomUUID(),
      employeeName: name,
      startDate: start,
      endDate: end,
      status,
      hasSchoolChildren,
      rejectionReason: reason,
      createdAt: Date.now()
    };

    setRequests(prev => [newReq, ...prev]);
    setIsSubmitting(false);
    return { status, reason };
  };

  const handleAdminAuth = () => {
    const pin = prompt("Bitte Admin-PIN eingeben (Standard: 1234):");
    if (pin === "1234") {
      window.location.hash = "";
      setViewMode('manager');
    } else {
      alert("Falsche PIN!");
    }
  };

  const approvedCount = requests.filter(r => r.status === RequestStatus.APPROVED || r.status === RequestStatus.PRIORITY).length;

  // Render isolated view for employees
  if (viewMode === 'employee') {
    return <EmployeePortal onSubmit={handleNewRequest} onAdminLogin={handleAdminAuth} />;
  }

  // Render full dashboard for manager
  return (
    <div className="min-h-screen bg-white">
      <Header onPortalClick={() => { window.location.hash = "portal"; setViewMode('employee'); }} />
      <Hero onStartClick={() => { window.location.hash = "portal"; setViewMode('employee'); }} />
      
      <main className="container mx-auto px-6 pb-20">
        <StatsCards 
          totalRequests={requests.length} 
          approvedCount={approvedCount} 
          config={config} 
        />

        <div className="mb-12 flex flex-col md:flex-row justify-between items-center gap-6">
          <SettingsCard config={config} setConfig={setConfig} />
          <button 
            onClick={() => {
              const url = window.location.href.split('#')[0] + '#portal';
              navigator.clipboard.writeText(url);
              alert('Mitarbeiter-Link kopiert! Sende diesen Link an deine Crew. In diesem Modus sehen Mitarbeiter KEINE Admin-Daten.');
            }}
            className="flex items-center gap-3 px-8 py-4 bg-slate-900 text-white rounded-2xl hover:bg-slate-800 transition-all text-sm font-bold shadow-2xl"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
            Portal-Link für Mitarbeiter kopieren
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          <div className="lg:col-span-8 space-y-12">
            <section id="calendar">
              <OccupancyHeatmap requests={requests} config={{ ...config, maxAway }} />
            </section>
            <section id="list">
              <HolidayList requests={requests} />
            </section>
          </div>

          <div className="lg:col-span-4 space-y-12">
            <section id="notifications">
              <NotificationCenter notifications={notifications} />
            </section>
            <div className="bg-teal-50 p-8 rounded-3xl border border-teal-100 shadow-sm">
                <h3 className="text-teal-900 font-bold mb-4 flex items-center gap-2">
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-teal-600"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>
                  Crew Insight (KI)
                </h3>
                {isAnalyzing ? (
                  <div className="space-y-3 animate-pulse">
                    <div className="h-3 bg-teal-200 rounded w-full"></div>
                    <div className="h-3 bg-teal-200 rounded w-5/6"></div>
                  </div>
                ) : (
                  <p className="text-sm text-teal-800 leading-relaxed italic font-medium opacity-80">
                    {insight || "Keine Kapazitätsengpässe in Sicht."}
                  </p>
                )}
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-slate-50 py-16 border-t border-slate-100 mt-20">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-teal-600 rounded-lg flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            </div>
            <span className="font-extrabold text-xl text-slate-900">CrewFlow</span>
          </div>
          <p className="text-sm text-slate-400 font-medium tracking-tight">© 2024 CrewFlow Systems — Human Resources Reimagined.</p>
        </div>
      </footer>
    </div>
  );
};

export default App;
